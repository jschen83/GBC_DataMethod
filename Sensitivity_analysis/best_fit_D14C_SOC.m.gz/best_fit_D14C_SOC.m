clear all;
clear global;
clf;
%
num0=9;
num1=11;
num2=12;
%
% New index ID
%
newindex=[56 53 29 55 68 23  3 62 65 37 49 32 25 39 59 40 16 12 14 15 34];
%
%% Jinsong's 14C site run data, 21 sites, obs at 10,30,50,70,100 cm
%% 5 tau x 2 root = 10 factorial runs

%% observations
data_14C = xlsread('lat-based-PFT.xlsx','14C');
data_14C_lon = data_14C(:,2);
data_14C_lat = data_14C(:,3);
data_14C_mu = data_14C(:,4:8);
data_14C_sd = data_14C(:,9:13);

data_SOC = xlsread('lat-based-PFT.xlsx','SOC');
data_SOC_lon = data_SOC(:,2);
data_SOC_lat = data_SOC(:,3);
data_SOC_mu = data_SOC(:,4:8);
data_SOC_sd = data_SOC(:,9:13);

%% ALM model
mypath = './';
mymodels = '14Csites';
mycase = 'TR1';
year = 2000;

% 10 ensembles
file01 = [mypath mymodels mycase sprintf('tau3.clm2.h0.%.4d-01-01-00000.nc',year)]; % tau=0.2, Jackson rooting profile
file02 = [mypath mymodels mycase sprintf('tau3_J.clm2.h0.%.4d-01-01-00000.nc',year)]; % tau=0.2, Zeng rooting profile
file03 = [mypath mymodels mycase sprintf('tau2.clm2.h0.%.4d-01-01-00000.nc',year)]; % 0.35, Jackson rooting profile
file04 = [mypath mymodels mycase sprintf('tau2_J.clm2.h0.%.4d-01-01-00000.nc',year)]; % 0.35, Zeng rooting profile
file05 = [mypath mymodels mycase sprintf('.clm2.h0.%.4d-01-01-00000.nc',year)]; % 0.5, Jackson rooting profile
file06 = [mypath mymodels mycase sprintf('_J.clm2.h0.%.4d-01-01-00000.nc',year)]; % 0.5, Zeng rooting profile
file07 = [mypath mymodels mycase sprintf('tau4.clm2.h0.%.4d-01-01-00000.nc',year)]; % 0.65, Jackson rooting profile
file08 = [mypath mymodels mycase sprintf('tau4_J.clm2.h0.%.4d-01-01-00000.nc',year)]; % 0.65, Zeng rooting profile
file09 = [mypath mymodels mycase sprintf('tau5.clm2.h0.%.4d-01-01-00000.nc',year)]; % 0.8, Jackson rooting profile
file10 = [mypath mymodels mycase sprintf('tau5_J.clm2.h0.%.4d-01-01-00000.nc',year)]; % 0.8, Zeng rooting profile

model_C14 = NaN(21,5,10);
model_SOC = NaN(17,5,10);
totvegc = NaN(21,10);
for i = 1 : 10
    filename = eval(sprintf('file%.2d',i));
    tmp_C14_s1 = ncread(filename,'C14_SOIL1C_vr');
    tmp_C14_s2 = ncread(filename,'C14_SOIL2C_vr');
    tmp_C14_s3 = ncread(filename,'C14_SOIL3C_vr');
    
    
    tmp_SOC_s1 = ncread(filename,'SOIL1C_vr');
    tmp_SOC_s2 = ncread(filename,'SOIL2C_vr');
    tmp_SOC_s3 = ncread(filename,'SOIL3C_vr');
    
    tmp_C14 = tmp_C14_s1 + tmp_C14_s2 + tmp_C14_s3;
    tmp_SOC = tmp_SOC_s1 + tmp_SOC_s2 + tmp_SOC_s3;
    tmp_deltaC14 = (tmp_C14./tmp_SOC/1e-12-1)/1e-3;
    
    model_C14(:,:,i) = tmp_deltaC14(:,[4:8]);
    model_SOC(:,:,i) = tmp_SOC([2,3,4,5,6,7,8,9,10,11,12,14,16,17,18,20,21],[4:8]); % soil depth 4-8 corresponding to 10,30,50,70,100cm

end
model_SOC = model_SOC/1000;

% figures
% SOC missing 4 sites, index are [1,13,15,19] in coresponding to model site index
tmp=colormap('jet'); % 64 color, this must be consistent for all figures

% best-fit scatter plot for 14C
myfit1 = [];
for i = 1 : 21 % sites
    for j = 1 : 5 % soil layers
        tmp = squeeze(model_C14(i,j,:) - data_14C_mu(i,j));
        [val, index]=min(tmp.^2);
        myfit1 = [myfit1; data_14C_mu(i,j) model_C14(i,j,index) index];
    end
end

subplot(2,1,1);
tmp=colormap('jet'); % 64 color, this must be consistent for all figures
plot([-900:100],[-900:100],'k-','LineWidth',2);hold;
for i = 1 : 105 % 21*5
    plot(myfit1(i,1),myfit1(i,2),'o','color',[tmp(myfit1(i,3)*6,:)],'MarkerSize',8);
end
xlim([-900 100]);
ylim([-900 100]);
xlabel('Observed \Delta^{14}C (per mil)','FontSize',num1);
ylabel('Modeled \Delta^{14}C (per mil)','FontSize',num1);
title('(a) \Delta^{14}C','FontSize',num2);
set(gca, 'FontSize',num1);
set(gca, ...
    'Box'         , 'on'     , ...
    'TickDir'     , 'in'     , ...
    'TickLength'  , [.01 .02] , ...
    'XMinorTick'  , 'off'      , ...
    'YMinorTick'  , 'on'      , ...
    'YGrid'       , 'off'      , ...
    'XColor'      , [.01 .01 .01], ...
    'YColor'      , [.01 .01 .01], ...
    'LineWidth'   , 1         );

myindex = 1;

% best-fit scatter plot for SOC
myfit2 = [];
myindex = 1;
for i = 1 : 21 % sites
    if (i~= 1 && i~=13 && i~=15 && i~=19) % no SOC observation sites
        for j = 1 : 5 % layers
            tmp = squeeze(model_SOC(myindex,j,:) - data_SOC_mu(myindex,j));
            [val, index]=min(tmp.^2);
            myfit2 = [myfit2; data_SOC_mu(myindex,j) model_SOC(myindex,j,index) index];
        end
        myindex = myindex + 1;
    end
end

subplot(2,1,2);
tmp=colormap('jet');
plot([0:80],[0:80],'k-','LineWidth',2);hold;
for i = 1 : 85 % 17sites*5layers
    plot(myfit2(i,1),myfit2(i,2),'o','color',[tmp(myfit2(i,3)*6,:)],'MarkerSize',8);
end
xlim([0 80]);
ylim([0 80]);
xlabel('Observed SOC (kg/m^3)','FontSize',num1);
ylabel('Modeled SOC (kg/m^3)','FontSize',num1);
title('(b) SOC','FontSize',num2);
set(gca, 'FontSize',num1);
set(gca, ...
    'Box'         , 'on'     , ...
    'TickDir'     , 'in'     , ...
    'TickLength'  , [.01 .02] , ...
    'XMinorTick'  , 'off'      , ...
    'YMinorTick'  , 'on'      , ...
    'YGrid'       , 'off'      , ...
    'XColor'      , [.01 .01 .01], ...
    'YColor'      , [.01 .01 .01], ...
    'LineWidth'   , 1         );

set(gcf,'paperposition',jcsize(6,10));
